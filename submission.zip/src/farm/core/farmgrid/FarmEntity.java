package farm.core.farmgrid;

import farm.core.UnableToInteractException;
import farm.inventory.product.Product;
import farm.inventory.product.data.Barcode;
import farm.inventory.product.data.Quality;

import java.util.List;

public abstract class FarmEntity {
    private final Entity entity;

    public FarmEntity(char symbol) {
        this.entity = Entity.getBySymbol(symbol);
    }

    public static FarmEntity createFarmEntity(char symbol, String farmType) {
        return switch (farmType) {
            case "plant" -> new Plant(symbol);
            case "animal" -> new Animal(symbol);
            default -> throw new IllegalArgumentException("Unknown farm type: " + farmType);
        };
    }

    protected FarmEntity getFarmEntity() {
        return this;
    }

    public char getSymbol() {
        return entity.getSymbol();
    }

    public String getName() {
        return entity.getName();
    }

    public Barcode getBarcode() {
        return entity.getBarcode();
    }

    public Product getProduct(Quality quality) {
        return entity.getProduct(quality);
    }

    public abstract void checkReadyForHarvest() throws UnableToInteractException;

    public abstract List<String> harvestEntity();

    public abstract String getType();

    public abstract List<String> feed() throws UnableToInteractException;

    public abstract List<String> reset();

    public abstract List<String> getPositionInfo();

    public abstract void initialiseFromPositionInfo(List<String> positionInfo);

}
