package farm.core.farmgrid;

import farm.core.UnableToInteractException;
import farm.inventory.product.*;
import farm.inventory.product.data.Quality;
import farm.inventory.product.data.RandomQuality;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class FarmGrid implements Grid {

    private final GridManager gridManager;
    private final EntityInteractionManager interactionManager;
    private final RandomQuality randomQuality;
    private final String farmType;


    /**
     * Constructor for the FarmGrid, creating a farm of specified type.
     * @param rows the number of rows on the grid
     * @param columns the number of columns on the grid
     * @requires rows > 0 && columns > 0
     */
    public FarmGrid(int rows, int columns, String farmType) {

        this.gridManager = new GridManager(rows, columns);
        this.interactionManager = new EntityInteractionManager(gridManager);
        this.randomQuality = new RandomQuality();
        this.farmType = farmType;
    }


    /**
     * Default constructor for the FarmGrid, creating a plant farm.
     *
     * NOTE: whatever class you implement that extends Grid *must* have a constructor
     * with this signature for testing purposes.
     *
     * @param rows the number of rows on the grid
     * @param columns the number of columns on the grid
     * @requires rows > 0 && columns > 0
     */
    public FarmGrid(int rows, int columns) {
        this(rows, columns, "plant");
    }

    public String getFarmType() {
        return farmType;
    }

    @Override
    public boolean place(int row, int column, char symbol) {

        FarmEntity entity;
        try {
            entity = FarmEntity.createFarmEntity(symbol, this.getFarmType());
        } catch (IllegalArgumentException | UnableToInteractException e) {
            return false;
        }
        if (!this.getFarmType().equals(entity.getType())) {
            throw new IllegalArgumentException(
                    "You cannot place a " + entity.getType() + " on a " + this.getFarmType()
            );
        }

        List<String> positionInfo = entity.getPositionInfo();
        return gridManager.placeEntity(row, column, entity, positionInfo);
    }


    @Override
    public int getRows() {
        return gridManager.getRows();
    }

    @Override
    public int getColumns() {
        return gridManager.getColumns();
    }


    public void remove(int row, int column) {
        gridManager.removeEntity(row, column);
    }

    @Override
    public String farmDisplay() {
        return gridManager.getGridDisplay();
    }

    @Override
    public List<List<String>> getStats() {
        return getTheFarmStatsList();
    }

    public Product harvest(int row, int column) throws UnableToInteractException {
        return interactionManager.harvest(row, column, randomQuality.getRandomQuality());
    }


    @Override
    public boolean interact(String command, int row, int column) throws UnableToInteractException {
        switch (command) {
            case "feed":
                interactionManager.feedEntity(row, column);
                return true;
            case "end-day":
                interactionManager.endDay();
                return true;
            case "remove":
                this.remove(row, column);
                return true;
            default:
                throw new UnableToInteractException("Unknown command: " + command);
        }
    }

    /**
     * Method for retrieving the stats for the current farm.
     * @return the list describing the current farm state
     */
    public List<List<String>> getTheFarmStatsList() {
        List<List<String>> farmStats = new ArrayList<>();

        // Iterate through each row and column of the farm grid
        for (int i = 0; i < getRows(); i++) {
            for (int j = 0; j < getColumns(); j++) {
                Cell cell = gridManager.getCell(i, j);

                // If the cell is not empty, add its positionInfo to farmStats
                if (!cell.isEmpty()) {
                    farmStats.add(cell.getPositionInfo());
                } else {
                    List<String> spotOnGrid = new ArrayList<>();
                    spotOnGrid.add("ground");
                    spotOnGrid.add(" ");
                    farmStats.add(spotOnGrid);
                }
            }
        }
        return farmStats;
    }

    public void addToCell(int row, int col, char entitySymbol, List<String> positionInfo) throws UnableToInteractException {
        Cell cell = gridManager.getCell(row, col);
        FarmEntity entity = FarmEntity.createFarmEntity(entitySymbol, this.getFarmType());
        if (this.getFarmType().equals("plant")) {
            int stage = positionInfo.get(2).charAt(positionInfo.get(2).length() - 1);
            ((Plant) entity).setGrowthStage(stage);
        } else {
            boolean fed = false;
            boolean collected = false;

            if (positionInfo.get(2).contains("true")) {
                fed = true;
            }
            if (positionInfo.get(3).contains("true")) {
                collected = true;
            }
            ((Animal) entity).setFed(fed);
            ((Animal) entity).setCollected(collected);
        }

        cell.addEntity(entity, positionInfo);
    }

}
